/*
	 We have to provide an URL link for one domain say "wiprodigital.com".
	 It will visit all the pages within the domain and The site map will show other
	 pages under the same domain, links to static content such as images and to external URLs and show the output in Plaintext.
	 
*/
package javaWebCrawler;
import java.io.IOException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
public class OutputPlaintext
   {
public static void main(String args[])
   {
          Document doc=null;
			try
			{
				doc=Jsoup.connect("https://wiprodigital.com/").get();
				String title=doc.title();
				System.out.println("Title:" +title);
				Elements links=doc.select("a[href]");
				for(Element link:links)
				{
					System.out.println(""+link.attr("href"));
					System.out.println("text:" +link.text());
					//System.out.println("Title:" +title);
				}
				
				
			}
			catch(IOException e)
			{
				e.printStackTrace();
			}
		}




	}
	
