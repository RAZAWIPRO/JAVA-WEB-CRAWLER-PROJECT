
/*
	 We have to provide an URL link for one domain say "wiprodigital.com".
	 It will visit all the pages within the domain and The site map will show other
	 pages under the same domain, links to static content such as images and to external 
	 URLs and show the output in HTML FORMAT.
	 
*/

package javaWebCrawler;
//import main.Bot;

public class ResultInHTML 
{
	public static void main(String[] args) 
	{
	//NOTE:Remove the comment to get the output from "wiprodigital.com" site
    
		//String start_url ="https://wiprodigital.com/";
		
		
		//NOTE:Put the appropriate  Testpage HTML folder location after downloading
     String start_url ="file:///E:/Javapoc/WEBCROWLER/Test%20Page/index.html";
	
	ResultInHTML1BOT bot = new ResultInHTML1BOT(start_url);
	
	bot.start();
	}
}
