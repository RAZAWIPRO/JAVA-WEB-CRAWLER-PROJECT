
//Please run ResultINHTML.java class to get HTML OUTPUT which has calling this class
package javaWebCrawler;
import java.io.*;
import java.net.*;
public class ResultInHTML1BOT
{

		private String start_url;
		public ResultInHTML1BOT(String start_url)
		{
			this.start_url = start_url;
			
		}
		
		public void start() {
			//crawl(this.start_url);
			//String xml=getXML(this.start_url);
			String html=getHTML(this.start_url);
			//System.out.println(html);
			
		}
		private String getHTML(String url)
		{
			URL u;
			try
			{
				u=new URL(url);
				URLConnection conn=u.openConnection();
				conn.setRequestProperty("User.Agent","/BBot/1.0");
				conn.setRequestProperty("Accept-Charset","UTF-8");
				InputStream is=conn.getInputStream();
				BufferedReader reader=new BufferedReader(new InputStreamReader(is));
				String line;
				String html="";
				while((line=reader.readLine())!=null)
				{
					html+=line+ "\n";
				}
				html=html.trim();
				//FileReader frInHtml=null;
				//frInHtml = new FileReader("file:///C:/Users/RAZA/Downloads/Test%20Page/index.html");
				System.out.println("Hi");
				System.out.println(html);
			    return html;
			}
			catch(Exception e)
			{
				e.printStackTrace();
				return null;
			}
			
	}
				
			
		
	}
	