/*
	 We have to provide an URL link for one domain say "wiprodigital.com".
	 It will visit all the pages within the domain and The site map will show other
	 pages under the same domain, links to static content such as images and to external URLs and show the output in Plaintext.
	 
*/
package javaWebCrawler;
import java.io.*;
//import java.io.BufferedInputStream;
//import java.io.BufferedReader;
//import java.io.BufferedWriter;
//import java.io.DataInputStream;
//import java.io.FileOutputStream; 
//import java.io.FileReader;
//import java.io.FileWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import org.jdom.JDOMException;
import org.jdom.input.SAXBuilder;
import org.jdom.output.XMLOutputter;
//import java.io.IOException;
public class ResultInXML
{

	//class HTML2XML
	
 public static void main(String args[]) throws JDOMException
		{
		 // System.out.println("Hi");
			InputStream isInHtml =null;
			URL url  = null;
			URLConnection connection =null;
			DataInputStream disInHtml =null;
			FileOutputStream fosOutHtml =null;
			FileWriter fwOutXml =null;
			FileReader frInHtml=null;
			 BufferedWriter bwOutXml =null;
			 BufferedReader brInHtml=null;
		try {
		     url  = new URL("www.climb.co.jp");
		    connection = url.openConnection();       
		     isInHtml = connection.getInputStream();
		 // System.out.println("Hi");
		     frInHtml = new FileReader("file:///C:/Users/RAZA/Downloads/Test%20Page/index.html");
		     System.out.println("Hi");
		     brInHtml = new BufferedReader(frInHtml);
		     System.out.println("Hi");
		     SAXBuilder saxBuilder = new SAXBuilder("org.ccil.cowan.tagsoup.Parser", false);
		     System.out.println("Hi");
		     org.jdom.Document jdomDocument = saxBuilder.build(brInHtml);
		     XMLOutputter outputter = new XMLOutputter();
		     try {
		          outputter.output(jdomDocument, System.out);
		          fwOutXml = new FileWriter("file:///C:/Users/RAZA/Downloads/Test%20Page/index.html");
		          bwOutXml = new BufferedWriter(fwOutXml);
		          outputter.output(jdomDocument, bwOutXml);
		          System.out.flush();
		      }
		      catch (IOException e) 
		     {  
		    	  
		     }
		            
		}
		catch (IOException e) 
		{ 
			
		}  
		finally {
		     System.out.flush();
		     try{
		     isInHtml.close();
		     disInHtml.close();                      
		     fosOutHtml.flush();
		     fosOutHtml.getFD().sync();
		     fosOutHtml.close();
		     fwOutXml.flush();
		     fwOutXml.close();
		     bwOutXml.close();
		     }
		     catch(Exception w)
		     {
		    	 
		     }
		}
		}
		}	
	
